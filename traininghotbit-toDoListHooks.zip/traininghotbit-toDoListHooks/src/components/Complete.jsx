import React from 'react'

const Complete = (props) => {
    const {data , changeStatus} = props
    return (
        <div>
            <ol>
                {
                    data.map( ({value,id,status}) => {
                        return(
                            <li>
                                <label>
                                    {value}
                                </label> <button onClick={changeStatus} value={id}>{status} Status</button>
                            </li>
                        )
                    })
                }
            </ol>
        </div>
    )
}
export default Complete
