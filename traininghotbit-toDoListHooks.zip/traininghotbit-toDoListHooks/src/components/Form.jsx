import React , {useState} from 'react';
import nextId from "react-id-generator";
import All from './All';
import Complete from './Complete';
import Pending from './Pending';

const Form = () => {
    const [toDo , setToDo] = useState('');
    const [toDoArray , setToDoArray] = useState([]);
    const [currentTab , setCurrentTab] = useState('all');
    const changeValue = ({target:{value}}) => setToDo(value);
    const saveToDo = () => {
        setToDoArray([...toDoArray,{
            id : nextId(),
            value : toDo ,
            status : 'incomplete'
        }])
        setToDo('')
    }
    const componentMapping =  {
        all: All,
        complete: Complete,
        incomplete: Pending
    }
    const all = () => {
        setToDoArray([...toDoArray,toDoArray.filter(task => task.status !== '')])
        setCurrentTab('all')
    }
    const complete = () => {
        setToDoArray([...toDoArray,toDoArray.filter(task => task.status === 'complete')])
        setCurrentTab('complete')
    }
    const incomplete = () => {
        setToDoArray([...toDoArray,toDoArray.filter(task => task.status === 'incomplete')])
        console.log(toDoArray);
        setCurrentTab('incomplete')
    }
    const changeStatus = ({target: { value }}) => {
        const objIndex = toDoArray.findIndex((val => val.id === value));
        const changedStaus = (toDoArray[objIndex].status === 'complete') ? 'incomplete' : 'complete';
        toDoArray[objIndex].status = changedStaus;
        setToDoArray(toDoArray)
    }

    const ComponentToRender = componentMapping[currentTab];
    
    return (
        <div>
            <input type='text' placeholder='Enter here...' value={toDo} onChange={changeValue}/> <button onClick={saveToDo}>Add</button><br/>
            <button onClick={all}>All</button> <button onClick={complete}>Complete</button> <button onClick={incomplete}>Incomplete</button>
            <ComponentToRender data={toDoArray} changeStatus={changeStatus}/>
        </div>
    )
}

export default Form
